import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RussiaBomb here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RussiaBomb extends Actor
{
    /**
     * Act - do whatever the RussiaBomb wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int time;
    public RussiaBomb(){
        time = 1000;
    }
    public void act()
    {
        // Add your action code here.
        time--;
        setLocation(getX()-10, getY());
        if (time<1){
            getWorld().removeObject(this);
        }
    }
}
