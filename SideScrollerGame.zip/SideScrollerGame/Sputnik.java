import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sputnik here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sputnik extends Actor
{
    /**
     * Act - do whatever the Sputnik wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int sputX = MyWorld.lastSputX;
    int dead = 0;
    int dieCooldown = 0;
    int gunShot = 0;
    int gunCoolStart = 0;
    int gunCooldown = 16;
    public void act()
    {
        sputX+=1;
        if (dead == 0){
        if (gunShot == 0){
            if(getX() < 790 && getX()>0){
                gunCooldown--;
                if (gunCoolStart == 0){
                    gunCooldown = Greenfoot.getRandomNumber(100)+50;
                    gunCoolStart = 1;
                }
                if (gunCooldown < 1){
                    getWorld().addObject(new laser(getRotation()), getX(), getY());
                    gunShot = 1;
            }
            }
        }
    }
        if (dead == 0){
            if(gunCooldown>15){
                turnTowards(MyWorld.heroX, MyWorld.heroY);
        }
            setLocation(sputX- MyWorld.X, getY());
        if(getX()<-200){
            getWorld().removeObject(this);
        }
        }else{
            dieCooldown--;
            if(dieCooldown<1){
                if (getY()<601){
                    setLocation(sputX - MyWorld.X, getY()+5);
                    setRotation(getRotation()-5);
                }else{
                    getWorld().removeObject(this);
                }
        }
        }
    }
}
