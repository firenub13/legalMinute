import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Hero extends Actor
{
    int cooldown = 0;
    int moveSpeed = 0;
    int rotationSpeed = 0;
    int canDamage = 0;
    int canDamageCooldown = 0;
    //constructor for Hero - methods are run once when a Hero actor is addded
    public Hero(){ 
    
    
    }
    
    public void act()
    {
        
        setRotation(getRotation()+rotationSpeed); //reset rotation to straight
        move(moveSpeed);
        MyWorld.heroX = getX();
        MyWorld.heroY = getY();
        if(canDamage == 0){
            canDamageCooldown--;
            if (canDamageCooldown<1){
                canDamage = 1;
            }
        }
        
        if(Greenfoot.isKeyDown("w") && moveSpeed<6){
            moveSpeed+=1;
        }else if(moveSpeed>0){
            moveSpeed-=1;
        }
        if (moveSpeed<0){
            moveSpeed=0;
        }
        if (moveSpeed>5){
            moveSpeed=5;
        }
        if(Greenfoot.isKeyDown("a") && rotationSpeed> -6){
            rotationSpeed-=1;
        }else if (rotationSpeed<0){
            rotationSpeed+=1;
        }
        if (rotationSpeed>5){
            rotationSpeed=5;
        }
        if(Greenfoot.isKeyDown("d") && rotationSpeed< 6){
            rotationSpeed+=1;
        }else if (rotationSpeed>0){
            rotationSpeed-=1;
        }
        if (rotationSpeed<-5){
            rotationSpeed= -5;
        }
        
        if (cooldown > 0){
                cooldown--;
            }
        if(Greenfoot.isKeyDown("space")){
            if (cooldown < 1){
                getWorld().addObject(new HeroMissle(getRotation()), getX(), getY());
                cooldown = 15;
            }
    }
        if(isTouching(gerome.class)){
            if (canDamage == 1){
                MyWorld.health--;
                canDamage = 0;
                canDamageCooldown = 200;
            }
        }else if(isTouching(russia.class)){
            if (canDamage == 1){
                MyWorld.health--;
                canDamage = 0;
                canDamageCooldown = 200;
            }
        }else if(isTouching(RussiaBomb.class)){
            if (canDamage == 1){
                MyWorld.health--;
                canDamage = 0;
                canDamageCooldown = 200;
            }
        }else if(isTouching(laser.class)){
            if (canDamage == 1){
                MyWorld.health-=2;
                canDamage = 0;
                canDamageCooldown = 200;
            }
        }


        if (MyWorld.health<1){
            MyWorld.lose = 1;
            getWorld().addObject(new end(), 400, 300);
        }else if (MyWorld.score>24){
            MyWorld.win = 1;
            getWorld().addObject(new end(), 400, 300);
        }
}
}
