import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class HeroMissle extends Actor
{
    int time;
    int dead;
    int dieCooldown = 0;
    int bombFrame = 0;
    int canTouch = 1;
    public HeroMissle(int rot){
        Greenfoot.playSound("launch.wav");
        setRotation(rot);
        time = 1000;
    }
    
    //code that responds to the "Run" button
    public void act()
    {
        time--;
        if (canTouch == 1){
            if (isTouching(gerome.class)){
                dead = 1;
                dieCooldown = 2;
                canTouch = 0;
            }else if (isTouching(russia.class)){
                dead = 1;
                dieCooldown = 2;
                canTouch = 0;
            }
    }
        
        if (dead == 0){
            move(10);
            if (time<1){
            getWorld().removeObject(this);
        }
        }else{
            dieCooldown--;
            if (dieCooldown<1){
                getWorld().addObject(new explosion(), getX(), getY());
                getWorld().removeObject(this);
        }else{
            move(5);
        }
    }
}
}
