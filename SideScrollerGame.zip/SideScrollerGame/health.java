import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class health here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class health extends Actor
{
    /**
     * Act - do whatever the health wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       if(MyWorld.health==5){
           setImage("5health.png");
       }else if(MyWorld.health==4){
           setImage("4health.png");
       }else if(MyWorld.health==3){
           setImage("3health.png");
       }else if(MyWorld.health==2){
           setImage("2health.png");
       }else if(MyWorld.health==1){
           setImage("1health.png");
       }else{
           setImage("0health.png");
       }
    }
}
