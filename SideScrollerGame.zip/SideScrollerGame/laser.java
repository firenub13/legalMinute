import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class laser extends Actor
{
    /**
     * Act - do whatever the laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int frames;
    public laser(int dir){
        setRotation(dir);
        frames = 0;
    }
    public void act()
    {
        // Add your action code here.
        frames++;
        if (frames<6){
            setImage("laser1.png");
        }else if (frames<11){
            setImage("laser2.png");
        }else if (frames<16){
            setImage("laser3.png");
        }else if (frames>19){
            getWorld().removeObject(this);
        }
    }
}
