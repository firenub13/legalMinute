import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class explosion extends Actor
{
    /**
     * Act - do whatever the explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int bombFrame = 0;
    public void act()
    {
        bombFrame++;
        if(bombFrame<6){
            setImage("boom1.gif");
        }else if(bombFrame<11){
            setImage("boom2.gif");
        }else if(bombFrame<16){
            setImage("boom3.gif");
        }else if(bombFrame<21){
            setImage("boom4.gif");
        }else if(bombFrame<26){
            setImage("boom5.gif");
        }else if(bombFrame<31){
            setImage("boom7.gif");
        }else if(bombFrame<36){
            setImage("boom8.gif");
        }else if(bombFrame<41){
            setImage("boom9.gif");
        }else if(bombFrame<46){
            setImage("boom10.gif");
        }else if(bombFrame<51){
            setImage("boom11.gif");
        }else if(bombFrame<56){
            setImage("boom13.gif");
        }else if(bombFrame<61){
            setImage("boom14.gif");
        }else if(bombFrame<66){
            setImage("boom15.gif");
        }else if(bombFrame<71){
            setImage("boom16.gif");
        }else if(bombFrame<76){
            setImage("boom17.gif");
        }else{
            getWorld().removeObject(this);
        }
    }
}
