import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class russia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class russia extends Actor
{
    /**
     * Act - do whatever the russia wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int russiaX = MyWorld.lastRussiaX;
    int dead = 0;
    int dieCooldown = 0;
    int gunCooldown = Greenfoot.getRandomNumber(100)+50;
    int scored = 0;
    public void act()
    {
        gunCooldown--;
        if (isTouching(HeroMissle.class)){
            dead = 1;
            dieCooldown = 1;
            if (scored == 0){
                MyWorld.score++;
                scored = 1;
            }
        }
        if (dead == 0){
            if (gunCooldown < 1){
            if(getX() < 1000 && getX()>0){
                getWorld().addObject(new RussiaBomb(), getX(), getY());
                gunCooldown = Greenfoot.getRandomNumber(50)+50;
            }
            }
            setLocation(russiaX- MyWorld.X, getY());
            if(getX()<-200){
            MyWorld.health--;
            getWorld().removeObject(this);
            }
        }else{
            dieCooldown--;
            if(dieCooldown<1){
                if (getY()<601){
                    setLocation(russiaX - MyWorld.X, getY()+5);
                    setRotation(getRotation()-5);
                }else{
                    getWorld().removeObject(this);
                }
        }
        }
    }
}
