import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class powerup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class powerup extends Actor
{
    /**
     * Act - do whatever the powerup wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int powerX = MyWorld.lastPowerX;
    public void act()
    {
        setLocation(powerX - MyWorld.X, getY());
        if (isTouching(Hero.class)){
            if (MyWorld.health<5){
            MyWorld.health++;
        }
            Greenfoot.playSound("caw.mp3");
            getWorld().removeObject(this);
        }
    }
}
